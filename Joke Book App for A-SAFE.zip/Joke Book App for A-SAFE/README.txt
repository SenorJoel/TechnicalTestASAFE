This can also be built using Cordova, Java (JDK 17), Gradle (Wrapper) Android Studio, due to not having full access to my PC as of this project.
I wasn't able to import it fully into a mobile app. 

This is something that would make it mobile exclusive where as HTML has allowed input from both PC, Android and ios users by creating a web app function, all that needs to be done is uploaded to a cloud server that hosts this website.

No external plugins or addons used as of right now. 


Notepad++ was used for construction of this app. I would usually use visual studio code but I wanted to challenge myself with something and take a step back.